title: 阿里大于发送短信验证码demo
date: '2019-09-01 18:09:07'
updated: '2019-09-01 18:09:07'
tags: [阿里云]
permalink: /articles/2019/09/01/1567332547114.html
---
### 使用阿里云的短信服务进行短信发送

#### 1.在阿里的短信服务申请短信签名以及短信模板
```
https://dysms.console.aliyun.com/dysms.htm
```
* 短信签名：
![image.png](https://upload-images.jianshu.io/upload_images/10118469-690acc3a3f1f035d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 短信模板：
![image.png](https://upload-images.jianshu.io/upload_images/10118469-0952b4024dddf258.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 阿里云AK
![image.png](https://upload-images.jianshu.io/upload_images/10118469-744fb38ce9113651.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


#### 代码实现
* 需要自行更改为自己的配置
```

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsResponse;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @description:
 * @author: hhdong
 * @createDate: 2019/8/6
 */
public class SmsService {


    /**
     * 产品名称:云通信短信API产品，固定值
     */
    private static final String product = "Dysmsapi";

    /**
     * 产品域名,开发者无需替换，固定值
     */
    private static final String domain = "dysmsapi.aliyuncs.com";

    /**
     * 阿里云控制台自己的AK 需替换
     */
    private static String accessKeyId = "####";

    /**
     * 阿里云控制台自己的secret 需替换
     */
    private static String accessKeySecret = "####";

    /**
     * 短信签名 需替换
     */
    private static String signName = "####";

    /**
     * 短信模板code 需替换
     */
    private static String templateCodeRegist = "####";

    /**
     * 超时时间
     */
    private static String defaultConnectTimeout = "100";

    private static String defaultReadTimeout = "100";


    /**
     * 发送验证码
     * @param phone
     * @param smsCode
     * @return
     * @throws ClientException
     * @throws IOException
     */
    public static SendSmsResponse sendSms(String phone, String smsCode) throws ClientException, IOException {

        System.setProperty("sun.net.client.defaultConnectTimeout", defaultConnectTimeout);
        System.setProperty("sun.net.client.defaultReadTimeout", defaultReadTimeout);
        /**
         * 初始化acsClient
         */
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
        DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
        IAcsClient acsClient = new DefaultAcsClient(profile);
        /**
         * 组装请求对象-具体描述见控制台-文档部分内容
         */
        SendSmsRequest request = new SendSmsRequest();
        /**
         * 必填:待发送手机号
         */
        request.setPhoneNumbers(phone);
        /**
         * 必填:短信签名-可在短信控制台中找到
         */
        request.setSignName(signName);
        /**
         * 必填:短信模板-可在短信控制台中找到
         */
        request.setTemplateCode(templateCodeRegist);
        /**
         * 可选:模板中的变量替换JSON串
         */
        request.setTemplateParam("{\"code\":\"" + smsCode + "\"}");
        SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
        return sendSmsResponse;
    }


    /**
     * 短信发送结果查询
     * @param bizId
     * @param phone
     * @return
     * @throws ClientException
     * @throws IOException
     */
    public static QuerySendDetailsResponse querySendDetails(String bizId, String phone) throws ClientException, IOException {

        System.setProperty("sun.net.client.defaultConnectTimeout", defaultConnectTimeout);
        System.setProperty("sun.net.client.defaultReadTimeout", defaultReadTimeout);

        /**
         * 初始化acsClient
         */
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
        DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
        IAcsClient acsClient = new DefaultAcsClient(profile);

        /**
         * 组装请求对象
         */
        QuerySendDetailsRequest request = new QuerySendDetailsRequest();
        /**
         * 必填-手机号码
         */
        request.setPhoneNumber(phone);
        /**
         * 可选-流水号
         */
        request.setBizId(bizId);
        /**
         * 必填-发送日期 支持30天内记录查询，格式yyyyMMdd
         */
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd");
        request.setSendDate(ft.format(new Date()));
        /**
         * 必填-页大小
         */
        request.setPageSize(10L);
        /**
         * 必填-当前页码从1开始计数
         */
        request.setCurrentPage(1L);
        QuerySendDetailsResponse querySendDetailsResponse = acsClient.getAcsResponse(request);
        return querySendDetailsResponse;
    }

    public static void main(String[] args) {
        try {
           SendSmsResponse sendSmsResponse = sendSms("####", "7766552");
            System.out.println(sendSmsResponse.getBizId());
            QuerySendDetailsResponse querySendDetailsResponse = querySendDetails("905701565077027198^0", "####");
            System.out.println(querySendDetailsResponse.getCode());
            System.out.println(querySendDetailsResponse.getMessage());
        } catch (ClientException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
```
* 发送效果
![image.png](https://upload-images.jianshu.io/upload_images/10118469-c00d8e3a5eb44dfd.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

#### 所需jar包maven地址 
```
dependencies {
    compile("com.aliyun:aliyun-java-sdk-core:4.0.6")
    compile("com.aliyun:aliyun-java-sdk-dysmsapi:1.1.0")
}
```
