title: 支付demo篇（07）-支付对接 -微信支付APP支付
date: '2019-09-06 14:17:10'
updated: '2019-09-06 14:17:10'
tags: [支付, JAVA]
permalink: /articles/2019/09/06/1567750630183.html
---
##### 添加commons-codec依赖
```
   compile group: 'commons-codec', name: 'commons-codec', version: '1.12'
```
##### 添加微信签名工具
```
public class WxPayUtil {

    /**
     * 生成签名. 注意，若含有sign_type字段，必须和signType参数保持一致。
     * @param data 待签名数据
     * @param key API密钥
     * @return 签名
     */
    public static String generateSignature(final Map<String, String> data, String key) throws Exception {
        Set<String> keySet = data.keySet();
        String[] keyArray = keySet.toArray(new String[keySet.size()]);
        Arrays.sort(keyArray);
        StringBuilder sb = new StringBuilder();
        for (String k : keyArray) {
            if (k.equals("sign")) {
                continue;
            }
            // 参数值为空，则不参与签名
            if (data.get(k).trim().length() > 0) {
                sb.append(k).append("=").append(data.get(k).trim()).append("&");
            }
        }
        sb.append("key=").append(key);
        return CoreUtil.MD5(sb.toString()).toUpperCase();

    }

    public static String sign(String text, String key, String input_charset) {
        text = text + "&key=" + key;
        return DigestUtils.md5Hex(getContentBytes(text, input_charset));
    }

    public static byte[] getContentBytes(String content, String charset) {
        if (charset == null || "".equals(charset)) {
            return content.getBytes();
        }
        try {
            return content.getBytes(charset);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("MD5签名过程中出现错误,指定的编码集不对,您目前指定的编码集是:" + charset);
        }
    }
}

```
##### 添加支付接口IPayService
```
 /**
     * 微信APP支付
     * @param payOrderVo
     * @return
     */
    Map wxAppPay(PayOrderVo payOrderVo);
```

##### 添加支付接口实现PayService
```
    @Override
    public Map wxAppPay(PayOrderVo payOrderVo) {
        try {
            String totalFee = String.valueOf(new BigDecimal((payOrderVo.getAmount())).multiply(new BigDecimal(100)).intValue());
            Map<String, String> map = new HashMap<String, String>() {{
                put("appid",BaseValue.WX_APP_ID);
                put("mch_id",BaseValue.WX_MCH_ID);
                put("nonce_str", CoreUtil.MD5(payOrderVo.getOrderId()));
                //交易类型trade_type 以下参数详见微信开发文档
                //https://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=4_2
                put("trade_type", PayConstant.TradeType.APP);
                //如果多商户架构 建议使用商户ID
                put("device_info", BaseValue.WX_MCH_ID);
                put("body", payOrderVo.getSubject());
                put("detail", payOrderVo.getBody());
                //支付订单号 全局唯一 用于通信 demo版使用UUID MD5
                put("out_trade_no",CoreUtil.MD5(UUID.randomUUID().toString()));
                //总金额
                put("total_fee",totalFee);
                put("spbill_create_ip", payOrderVo.getClientIp());
                put("notify_url", BaseValue.SYSTEM_NOTIFY_URL);
            }};
            String prestr = XMLBeanUtil.createLinkString(map);
            String mysign = WxPayUtil.sign(prestr,BaseValue.WX_MCH_KEY, "utf-8").toUpperCase();
            map.put("sign", mysign);
            String xmlString = XMLBeanUtil.map2XmlString(map);
            String post = OkHttpClientUtil.doPost(BaseValue.WX_ORDER_URL, xmlString);
            return XMLBeanUtil.doXMLParse(post);
        } catch (Exception e) {
            logger.info("【微信APP支付请求失败 {}】",e.getMessage());
        }
        return null;
    }
```

##### 测试接口
```
http://127.0.0.1:8080/pay?orderId=123456789&userId=123456789&mobile=123456789&openId=123456789&payType=WX_PAY&tradeType=APP&trxType=XF&subject=测试微信APP支付subject&body=测试微信APP支付body&clientIp=127.0.0.1&amount=0.01&remark=测试微信二维码支付
```
![image.png](https://img.hacpai.com/file/2019/09/image-90befda2.png)

##### 几点注意
* 1.需要对微信支付进行签名
* 2.由于微信没有官方提供调试工具所以此操作无法调试需要安卓或者IOS对接联调
* 3.我自行测试是没有问题的
