title: Linux下搭建seafile（pro版）
date: '2019-09-01 18:17:26'
updated: '2019-09-01 18:17:26'
tags: [Linux]
permalink: /articles/2019/09/01/1567333046208.html
---
#### 搭建环境：centos7.4 64（华为云 阿里云亲测）
#### 连接工具：xshell、xftp（免费版） 
#### seafile版本: 6.29 (pro）

### 步骤
* 第一步： 
 上传seafile安装包到opt目录 （opt为默认安装目录 暂时不建议修改）
![image.png](https://upload-images.jianshu.io/upload_images/10118469-cc1cc6aae57c7e35.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 第二步：
执行安装指令、很简单不再一一赘述
```yaml
wget https://raw.githubusercontent.com/haiwen/seafile-server-installer-cn/master/seafile-server-centos-7-amd64-http

chmod +x seafile-server-centos-7-amd64-http

bash seafile-server-centos-7-amd64-http 6.2.9
````
执行完毕会出现以下界面
![image.png](https://upload-images.jianshu.io/upload_images/10118469-e96443d1c270ad72.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
选择pro版本
--------------------------------------------------------------------
     等待一键安装。。。。。。。。
---------------------------------------------------------------------
* 第三步：（安装完成生成初始化账号密码）
![image.png](https://upload-images.jianshu.io/upload_images/10118469-6d3a47efce24b9d6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 第四步：
登录：默认地址为：http://ip:8000  到此结束
![image.png](https://upload-images.jianshu.io/upload_images/10118469-3e0c7b2862f941e5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

#### 常见问题
* 访问不了：查看安全组是否开放8000、8002端口、本地防火墙开放8000端口
#### 安装包下载地址：
```yaml
http://sanmeng.oss-cn-beijing.aliyuncs.com/seafile/seafile-pro-server_6.2.9_x86-64.tar.gz
2019-07-01更新：https://www.lanzous.com/i4smb5a
```
