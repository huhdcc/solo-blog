title: 支付demo篇（01）-搭建支付服务
date: '2019-09-05 17:40:11'
updated: '2019-09-05 17:40:11'
tags: [JAVA, 支付]
permalink: /articles/2019/09/05/1567676411211.html
---
#### 构建支付项目

##### 项目结构
![image.png](https://img.hacpai.com/file/2019/09/image-a1b54390.png)

##### 项目依赖
```
apply plugin: 'java'
apply plugin: 'maven'

group 'com.huhdcc'
version '1.0-SNAPSHOT'
def artifactId="pay"
archivesBaseName="pay-demo"
sourceCompatibility = 1.8

sourceSets {
    main
}

repositories {
    mavenCentral()
}

dependencies {
    compile("org.springframework.boot:spring-boot-starter-web:2.1.7.RELEASE")
    testCompile group: 'junit', name: 'junit', version: '4.12'
}

```
##### 项目测试
```
package com.huhdcc.pay.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @description:
 * @author: hhdong
 * @createDate: 2019/9/5
 */
@RestController
public class IndexController {

    @RequestMapping("/index")
    public String index(){
        return "HELLO PAY";
    }
}

```
##### 测试访问
![image.png](https://img.hacpai.com/file/2019/09/image-464f453f.png)
 
