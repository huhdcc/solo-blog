title: Mybatis分析（13）-加载数据厂商标识databaseIdProviderElement
date: '2019-09-04 15:35:17'
updated: '2019-09-04 15:35:17'
tags: [Mybatis]
permalink: /articles/2019/09/04/1567582517817.html
---
* Mybatis可以根据不同的数据库厂商去执行不同的语句
* 多厂商的支持主要是基于映射语句中的databaseId属性
* mybatis会加载带匹配当前数据库databaseId和不带databaseId属性的所有语句
* 为了支持多厂商数据源只要在mybatis-config.xml的文件加入databaseIdProvider即可
```
<databaseIdProvider type="DB_VENDOR" />
```
* DB_VENDOR会通过DatabaseMetaData#getDatabaseProductName()返回的字符串进行复制
* 通常情况下这个字符串都非常长而且相同产品的不同版本会返回不同的值，所以最好通过设置属性别名来使其变短
 
```
<databaseIdProvider type="DB_VENDOR">  
	<property name="SQL Server" value="sqlserver"/>  
	<property name="MySQL" value="mysql"/> 
	<property name="Oracle" value="oracle" />  
</databaseIdProvider>
```
* 在有 properties 时，DB_VENDOR databaseIdProvider 的将被设置为第一个能匹配数据库产品名称的属性键对应的值，如果没有匹配的属性将会设置为 “null”
* 因为每个数据库在实现的时候，getDatabaseProductName() 返回的通常并不是直接的Oracle或者MySQL，而是“Oracle (DataDirect)”，所以如果希望使用多数据库特性，一般需要实现 org.apache.ibatis.mapping.DatabaseIdProvider接口 并在 mybatis-config.xml 中注册来构建自己的 DatabaseIdProvider： 
```
  public interface DatabaseIdProvider {
    void setProperties(Properties p);
    String getDatabaseId(DataSource dataSource) throws SQLException;
  }
```
* 典型的实现比如：
```
public class VendorDatabaseIdProvider implements DatabaseIdProvider {

    private static final Log log = LogFactory.getLog(VendorDatabaseIdProvider.class);

    private Properties properties;

    @Override
    public String getDatabaseId(DataSource dataSource) {
        if (dataSource == null) {
            throw new NullPointerException("dataSource cannot be null");
        }
        try {
            return getDatabaseName(dataSource);
        } catch (Exception e) {
            log.error("Could not get a databaseId from dataSource", e);
        }
        return null;
    }
  ...
    private String getDatabaseName(DataSource dataSource) throws SQLException {
        String productName = getDatabaseProductName(dataSource);
        if (this.properties != null) {
            for (Map.Entry<Object, Object> property : properties.entrySet()) {
                // 只要包含productName中包含了property名称,就算匹配，而不是使用精确匹配
                if (productName.contains((String) property.getKey())) {
                    return (String) property.getValue();
                }
            }
            // no match, return null
            return null;
        }
        return productName;
    }

    private String getDatabaseProductName(DataSource dataSource) throws SQLException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            DatabaseMetaData metaData = con.getMetaData();
            return metaData.getDatabaseProductName();
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    // ignored
                }
            }
        }
    }
}
```
