title: Mybatis分析（12）-加载环境配置environmentsElement
date: '2019-09-04 14:53:47'
updated: '2019-09-04 14:54:01'
tags: [Mybatis]
permalink: /articles/2019/09/04/1567580027171.html
---
* 环境配置可以说是整个mybatis配置文件加载的最核心的一部分，允许给开发，测试，生产环境配置不同的环境
* 如果在SqlSessionFactoryBuilder的调用期间没有指定环境配置的，默认会使用一个名为default的环境
* 在配置好环境以后，开始加载数据源以及事务管理器
* 事务管理器和数据源都用到了类型别名
* JDBC/POOLED都是mybatis内置的，在configuration构造器执行的时候注册到TypeAliasRegister
* mybatis提供了两张事务管理方式一种简单的JDBC模式，另一种主要是容器管理事务
* mybatis还提供了JNDI,POOLED,UNPOOLED三种数据源工厂，通常情况下使用POOLED数据源
```
<environments default="development">
        <environment id="development">
            <transactionManager type="JDBC"/>
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.jdbc.Driver/>
                <property name="url" value="jdbc:mysql://127.0.0.1:3306/base?useUnicode=true"/>
                <property name="username" value="root"/>
                <property name="password" value="root"/>
            </dataSource>
        </environment>
    </environments>
```
