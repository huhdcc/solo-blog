title: IDEA授权服务器搭建
date: '2019-09-03 17:35:40'
updated: '2019-09-03 17:35:40'
tags: [IDEA, 工具]
permalink: /articles/2019/09/03/1567503340844.html
---

#### 下载安装文件
https://pan.baidu.com/s/1i48owPB
#### 选择适合自己的版本
![image.png](https://img.hacpai.com/file/2019/09/image-c0168e29.png)

#### 在服务器执行命令
```
   chmod a+x IntelliJIDEALicenseServer_linux_amd64

  ./IntelliJIDEALicenseServer_linux_amd64
```

#### 测试
http://你的ip:1017
