title: jdk环境变量一键配置
date: '2019-09-01 18:15:05'
updated: '2019-09-01 18:15:05'
tags: [工具]
permalink: /articles/2019/09/01/1567332905549.html
---
##### 对于一些配置jdk环境变量比较困难的小伙伴,现在福音来了,我将在下面配上一键配置环境变量的批处理文件.只需要双击运行就能完成配置
##### 但是学习的Java的同学不要只依赖于工具,不会配置的一定要学会配置,因为以后都是要自己去配置环境变量的,不要只依赖于工具,自己懂了怎么配置才是最主要的.
>代码
```
 ![image.png](https://upload-images.jianshu.io/upload_images/10118469-2fa7648734a91d65.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


@echo off
echo ************************************************************  
echo *                                                          *  
echo *        JDK 系统环境变量设置,请用管理员身份运行           *  
echo *                                                          *  
echo ************************************************************  
echo.    
:START
set /p javahome=请输入JDK安装路径：
IF EXIST "%javahome%\bin\java.exe" GOTO INSTALL
:WARNING
rem 输入目录错误，提示重新输入
echo 您所输入的路径不是JDK安装路径
echo 请重新输入正确的JDK安装路径
pause
goto START
:INSTALL
rem 如输入正确的 JavaSDK 安装目录，开始设置环境变量
echo 输入的路径是:%javahome%
rem LPY  
echo.  
echo === 准备设置环境变量: JAVA_HOME=%javahome%  
echo === 注意: 如果JAVA_HOME存在,会被覆盖,此操作不可逆的,请仔细检查确认!! ===  
echo.  
echo === 准备设置环境变量(后面有个.): CLASSPATH=.;%%JAVA_HOME%%\lib\dt.jar;%%JAVA_HOME%%\lib\tools.jar;  
echo === 注意: 如果CLASSPATH存在,会被覆盖,此操作不可逆的,请仔细检查确认!! ===  
echo.  
echo === 准备设置环境变量: PATH=%%JAVA_HOME%%\bin;%%JAVA_HOME%%\jre\bin;  
echo === 注意: PATH会追加在最前面,  
echo.  
set /P EN=请确认后按 回车键 开始设置!  
echo.  
echo.  
echo.  
echo.  
echo === 新创建环境变量 JAVA_HOME=%javahome%  
setx "JAVA_HOME" "%javahome%" -M  
echo.  
echo.  

echo === 新创建环境变量 CLASSPATH=.;%%JAVA_HOME%%\lib\dt.jar;%%JAVA_HOME%%\lib\tools.jar;  
setx "CLASSPATH" ".;%%JAVA_HOME%%\lib\dt.jar;%%JAVA_HOME%%\lib\tools.jar;" -M  
echo.  
echo.  
echo === 新追加环境变量(追加到最前面) PATH=%%JAVA_HOME%%\bin;%%JAVA_HOME%%\jre\bin;   

wmic ENVIRONMENT where "name='path' and username='<system>'" set VariableValue="%%JAVA_HOME%%\bin;%%JAVA_HOME%%\jre\bin;%path%"
setx path "%path%"
echo.  
echo.  
rem LPY http://blog.csdn.net/sadwxds/article/details/52984272 
echo === 请按任意键退出!   
pause>nul
```
* 新建一个文本文件 复制进去 然后更改txt后缀名为bats双击运行即可完成环境的配置.
