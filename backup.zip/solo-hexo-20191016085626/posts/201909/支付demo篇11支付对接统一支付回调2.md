title: 支付demo篇（11）-支付对接 - 统一支付回调（2）
date: '2019-09-06 20:08:13'
updated: '2019-09-06 20:30:30'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567771693628.html
---
##### 支付宝回调
```
@Override
    public String aliPayCallback(Map params) {
        boolean signVerif = false;
        try {
            signVerif = AlipaySignature.rsaCheckV1(params, BaseValue.ALI_PAY_PUBLIC_KEY, BaseValue.ALI_CHARSET, BaseValue.ALI_SIGN_TYPE);
        } catch (AlipayApiException e) {
            logger.info("【支付宝签名验证失败】");
        }
        if (signVerif) {
            //再次验证支付
            /**
              1.支付APPID
              2.支付金额
              3.支付订单号
              ....具体可根据业务检验
             */

            //开启新的线程处理业务
            ThreadManager.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    //业务逻辑
                }
            });
            //验证成功后返回支付宝SUCCESS标识 否则支付宝会多次回调
            return "SUCCESS";
        } else {
            logger.info("【支付宝参数验证失败】");
        }
        return "FALSE";
    }
```
##### 微信回调
```
@Override
    public String wxPayCallback(Map params) {
        boolean signVerif = false;
        try {
            //签名验证
            signVerif = WxPayUtil.verify(params, BaseValue.WX_MCH_KEY, "UTF-8".toUpperCase());
        } catch (Exception e) {
            logger.info("【微信签名验证失败】");
        }
        if(signVerif){
            //再次验证支付
            /**
             1.支付APPID
             2.支付金额
             3.支付订单号
             ....具体可根据业务检验
             */
            ThreadManager.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    //业务逻辑
                }
            });
            //验证成功后返回微信SUCCESS标识 否则微信会多次回调
            Map<String, String> returnMap = new HashMap<>();
            returnMap.put("return_code", "SUCCESS");
            returnMap.put("return_msg", "OK");
            return XMLBeanUtil.map2XmlString(returnMap);
        }else{
            logger.info("【微信参数验证失败】");
        }
        return "FALSE";
    }
```

###### 微信签名工具类
```
   /**
     * 签名验证
     * @param params
     * @param key
     * @param chartset
     * @return
     */
    public static boolean verify(Map params, String key, String chartset) {
        SortedMap<String,String> payInfo = new TreeMap<>(params);
        String sign = payInfo.get("sign");
        String prestr = XMLBeanUtil.createLinkString(WxPayUtil.paraFilter(payInfo));
        String mysign = WxPayUtil.sign(prestr, key, chartset.toUpperCase());
        if(mysign.toLowerCase().equals(sign.toLowerCase())){
            return true;
        }
        return false;
    }

    /**
     * 除去数组中的空值和签名参数
     * @param sArray 签名参数组
     * @return 去掉空值与签名参数后的新签名参数组
     */
    public static Map<String, String> paraFilter(Map<String, String> sArray) {
        Map<String, String> result = new HashMap<String, String>();
        if (sArray == null || sArray.size() <= 0) {
            return result;
        }
        for (String key : sArray.keySet()) {
            String value = sArray.get(key);
            if (value == null || value.equals("") || key.equalsIgnoreCase("sign")
                    || key.equalsIgnoreCase("sign_type")) {
                continue;
            }
            result.put(key, value);
        }
        return result;
    }

```
###### 测试支付回调
* 1.需要修改写死的回调常量
* 2.不可使用本地地址进行回调，可以使用第三方内网穿透
* 3.使用支付宝二维码支付进行测试
* 4.这里更改了我的本地端口，内网穿透我的为8094端口
```
http://127.0.0.1:8094/pay?orderId=123456789&userId=123456789&mobile=123456789&openId=o8gYN5DD3tArbH6IQTOuv_bDs2GU&payType=ALI_PAY&tradeType=QR&trxType=XF&subject=测试支付宝二维码支付subject&body=测试支付宝二维码支付body&clientIp=127.0.0.1&amount=0.01&remark=测试支付宝二维码支付
```
![image.png](https://img.hacpai.com/file/2019/09/image-2febff4a.png)
![image.png](https://img.hacpai.com/file/2019/09/image-4930b351.png)
* 可以看见已经成功回调具体业务可根据需求自行实现

