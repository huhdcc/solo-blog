title: 支付demo篇（13）-支付对接 -退款（2）
date: '2019-09-06 20:47:59'
updated: '2019-09-06 20:47:59'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567774079098.html
---
##### 添加微信退款接口IPayService
```
    /**
     * 微信退款
     * @param payOrderVo
     * @return
     */
    Map wxPayRefund(PayOrderVo payOrderVo);
```
##### 添加微信退款接口实现PayService
```
@Override
    public Map wxPayRefund(PayOrderVo payOrderVo) {
        try{
            Map<String, String> dataMap = new HashMap<>();
            dataMap.put("appid",BaseValue.WX_APPLET_APP_ID);
            dataMap.put("mch_id",BaseValue.WX_APPLET_MCH_ID);
            //自行实现该随机串
            dataMap.put("nonce_str", CoreUtil.MD5(payOrderVo.getOrderId()));
            //由系统生成我们保证唯一值 下单时的参数
            dataMap.put("out_trade_no",CoreUtil.MD5(payOrderVo.getOrderId()));
            //退款单号 由我们保证唯一
            dataMap.put("out_refund_no", CoreUtil.MD5(UUID.randomUUID().toString()));
            //总金额
            dataMap.put("total_fee", String.valueOf(new BigDecimal((payOrderVo.getAmount())).multiply(new BigDecimal(100)).intValue()));
            //退款金额 demo这里使用总金额
            dataMap.put("refund_fee", String.valueOf(new BigDecimal((payOrderVo.getAmount())).multiply(new BigDecimal(100)).intValue()));
            dataMap.put("refund_desc", payOrderVo.getRefundAmount() + "");
            //生成签名
            String sign = WxPayUtil.generateSignature(dataMap, BaseValue.WX_MCH_KEY);
            dataMap.put("sign", sign);
            //map数据转xml
            String xmlString = XMLBeanUtil.map2XmlString(dataMap);
            /**
             * 注意PKCS12证书 是从微信商户平台-》账户设置-》 API安全 中下载的
             */
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            //这里自行实现我是使用数据库配置将证书上传到了服务器可以使用 FileInputStream读取本地文件
            ByteArrayInputStream inputStream = FileUtil.getInputStream(BaseValue.WX_CRET_PATH);
            try {
                //这里写密码..默认是你的MCHID
                keyStore.load(inputStream, BaseValue.WX_MCH_KEY.toCharArray());
            } finally {
                inputStream.close();
            }
            SSLContext sslcontext = SSLContexts.custom()
                    //这里也是写密码的
                    .loadKeyMaterial(keyStore, BaseValue.WX_MCH_ID.toCharArray())
                    .build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
                    sslcontext,
                    SSLConnectionSocketFactory.getDefaultHostnameVerifier());
            CloseableHttpClient httpclient = HttpClients.custom()
                    .setSSLSocketFactory(sslsf)
                    .build();
            try {
                HttpPost httpost = new HttpPost(BaseValue.WX_REFUND_URL);
                httpost.setEntity(new StringEntity(xmlString, "UTF-8"));
                CloseableHttpResponse response = httpclient.execute(httpost);
                try {
                    HttpEntity entity = response.getEntity();
                    //接受到返回信息
                    String jsonStr = EntityUtils.toString(response.getEntity(), "UTF-8");
                    EntityUtils.consume(entity);
                    logger.info("【微信退款操作返回信息 jsonStr={} 】", jsonStr);
                    return XMLBeanUtil.doXMLParse(jsonStr);
                } finally {
                    response.close();
                }
            } finally {
                httpclient.close();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
```
###### 测试退款
* 使用刚才支护宝回调的信息，需要拿到支护宝返回的ID进行回调
![image.png](https://img.hacpai.com/file/2019/09/image-ad8d6ab5.png)
* 发起退款
```
http://127.0.0.1:8094/refund?orderId=1234567891&userId=123456789&mobile=123456789&openId=o8gYN5DD3tArbH6IQTOuv_bDs2GU&payType=ALI_PAY&tradeType=QR&trxType=XF&subject=测试支付宝二维码支付subject&body=测试支付宝二维码支付body&clientIp=127.0.0.1&amount=0.01&remark=测试支付宝二维码支付&payId=2019090622001412351052975079
```
* 退款结果
![image.png](https://img.hacpai.com/file/2019/09/image-320d7268.png)


