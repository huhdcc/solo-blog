title: Mybatis分析（10）-加载对象包装器工厂objectWrapperFactoryElement
date: '2019-09-04 14:36:07'
updated: '2019-09-04 14:36:07'
tags: [Mybatis]
permalink: /articles/2019/09/04/1567578967567.html
---
```
  private void objectWrapperFactoryElement(XNode context) throws Exception {
    //如果定义了
    if (context != null) {
      //获取type的值
      String type = context.getStringAttribute("type");
      //实例化
      ObjectWrapperFactory factory = (ObjectWrapperFactory) resolveClass(type).getDeclaredConstructor().newInstance();
      //赋值
      configuration.setObjectWrapperFactory(factory);
    }
  }
```
* 对象包装器工厂主要是用来包装返回result的对象
* 可以用来设置字段脱敏以及机密
* 默认的对象包装器工厂是DefaultObjectWrapperFactory　　
![image.png](https://img.hacpai.com/file/2019/09/image-a18290c1.png)

* BeanWrapper是BaseWrapper的实现，其中最主要的方法是getBeanProperty和setBeanProperty,这是实现包装的主要位置
![image.png](https://img.hacpai.com/file/2019/09/image-2590535d.png)
* 部分代码如下
```
 private Object getBeanProperty(PropertyTokenizer prop, Object object) {
    try {
      Invoker method = metaClass.getGetInvoker(prop.getName());
      try {
        return method.invoke(object, NO_ARGUMENTS);
      } catch (Throwable t) {
        throw ExceptionUtil.unwrapThrowable(t);
      }
    } catch (RuntimeException e) {
      throw e;
    } catch (Throwable t) {
      throw new ReflectionException("Could not get property '" + prop.getName() + "' from " + object.getClass() + ".  Cause: " + t.toString(), t);
    }
  }

  private void setBeanProperty(PropertyTokenizer prop, Object object, Object value) {
    try {
      Invoker method = metaClass.getSetInvoker(prop.getName());
      Object[] params = {value};
      try {
        method.invoke(object, params);
      } catch (Throwable t) {
        throw ExceptionUtil.unwrapThrowable(t);
      }
    } catch (Throwable t) {
      throw new ReflectionException("Could not set property '" + prop.getName() + "' of '" + object.getClass() + "' with value '" + value + "' Cause: " + t.toString(), t);
    }
  }
```

* 如果要自定包装器工厂,只需要实现ObjectWrapperFactory中的hasWrapperFor和getWrapperFor两个接口即可： 
```
  public class CustomBeanWrapperFactory implements ObjectWrapperFactory {
    @Override
    public boolean hasWrapperFor(Object object) {
      if (object instanceof Author) {
        return true;
      } else {
        return false;
      }
    }

    @Override
    public ObjectWrapper getWrapperFor(MetaObject metaObject, Object object) {
      return new CustomBeanWrapper(metaObject, object);
    }
  }
```
