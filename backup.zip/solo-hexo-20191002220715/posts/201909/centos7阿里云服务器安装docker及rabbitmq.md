title: centos7 阿里云服务器安装docker及rabbitmq
date: '2019-09-01 18:18:25'
updated: '2019-09-01 18:18:25'
tags: [Linux]
permalink: /articles/2019/09/01/1567333104951.html
---
##### 1. 更新yum (耗时)
```
yum update
```
##### 2.安装驱动依赖
 ```
yum install -y yum-utils device-mapper-persistent-data lvm2
```
##### 3.设置一下yum源
```
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
```
##### 4.安装docker
```
yum install docker-ce-17.12.1.ce
```
版本自行选择
##### 5.启动docker并加入自启动,查看版本
```
systemctl start docker
systemctl enable docker
docker version 
```
##### 6.拉取rabbitmq
 ```
docker pull docker.io/rabbitmq
```
##### 7.启动rabbitmq
```
docker run -d --name myrabbitmq -p 5673:5672 -p 15673:15672 docker.io/rabbitmq:3-management
```
##### 8.访问
[http://IP:15673/](http://huhdcc.top:15673/)
##### 9.其他命令
```
清楚所有容器以及镜像
docker rm `docker ps -a -q`
docker rmi `docker images -q`
```
