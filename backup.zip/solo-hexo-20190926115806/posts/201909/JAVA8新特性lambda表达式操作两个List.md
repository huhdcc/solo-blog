title: JAVA8新特性lambda表达式（操作两个List）
date: '2019-09-01 18:14:22'
updated: '2019-09-01 18:14:22'
tags: [JAVA8]
permalink: /articles/2019/09/01/1567332862530.html
---
### 两个List通过相同的属性值进行个别属性赋值
##### 需求：List<UserVo> 用户对象  List<CustLoginLogVo> 用户登录对象，将CustLoginLogVo集合中按用户全局ID进行匹配把用户的最后登录时间set到对应的UserVo中
##### UserVo:
```
public class UserVo{
	@ApiModelProperty(value = "用户全局ID")
	private String custGlobalId;
 
	@ApiModelProperty(value = "最后登录时间")
	private Date lastLoginTime;
}
```
##### CustLoginLogVo:
```
public class CustLoginLogVo{
	@ApiModelProperty(value = "用户全局ID")
	private String custGlobalId;
 
	@ApiModelProperty(value = "最后登录时间")
	private Date lastLoginTime;
}
```

##### 实现代码：
```
List<UserVo> userList = new ArrayList<>();//这里要非空
List<CustLoginLogVo> custLoginLogVos =  new ArrayList<>();//这里要非空 业务代码不贴出来
			if(ValidateHelper.isNotEmptyCollection(custLoginLogVos)) {
				userList = userList
						.stream()
						.map(user -> custLoginLogVos.stream()
								.filter(log -> user.getCustGlobalId().equals(log.getCustGlobalId()))
								.findFirst()
								.map(log -> {
									user.setLastLoginTime(log.getLoginTime());
									return user;
								})
								.orElse(user))
						.collect(Collectors.toList());
			}
```
