title: centos7 阿里云服务器docker安装redis
date: '2019-09-01 18:19:54'
updated: '2019-09-01 18:19:54'
tags: [Linux]
permalink: /articles/2019/09/01/1567333194883.html
---
#### centos7 阿里云服务器docker安装redis
#### docker安装请阅读其他文章已有介绍
* 搜索redis镜像
```
docker search redis
```
```
[root@izj6c5c5zhif1dhww06p26z ~]# docker search redis
NAME                             DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
redis                            Redis is an open source key-value store that…   7219                [OK]                
bitnami/redis                    Bitnami Redis Docker Image                      122                                     [OK]
sameersbn/redis                                                                  77                                      [OK]
grokzen/redis-cluster            Redis cluster 3.0, 3.2, 4.0 & 5.0               53                                      
kubeguide/redis-master           redis-master with "Hello World!"                29                                      
rediscommander/redis-commander   Alpine image for redis-commander - Redis man…   29                                      [OK]
redislabs/redis                  Clustered in-memory database engine compatib…   23                                      
arm32v7/redis                    Redis is an open source key-value store that…   17                                      
redislabs/redisearch             Redis With the RedisSearch module pre-loaded…   16                                      
oliver006/redis_exporter          Prometheus Exporter for Redis Metrics. Supp…   13                                      
webhippie/redis                  Docker images for Redis                         10                                      [OK]
s7anley/redis-sentinel-docker    Redis Sentinel                                  9                                       [OK]
redislabs/redisgraph             A graph database module for Redis               7                                       [OK]
bitnami/redis-sentinel           Bitnami Docker Image for Redis Sentinel         7                                       [OK]
insready/redis-stat              Docker image for the real-time Redis monitor…   7                                       [OK]
arm64v8/redis                    Redis is an open source key-value store that…   6                                       
centos/redis-32-centos7          Redis in-memory data structure store, used a…   4                                       
redislabs/redismod               An automated build of redismod - latest Redi…   4                                       [OK]
frodenas/redis                   A Docker Image for Redis                        2                                       [OK]
wodby/redis                      Redis container image with orchestration        2                                       [OK]
circleci/redis                   CircleCI images for Redis                       2                                       [OK]
runnable/redis-stunnel           stunnel to redis provided by linking contain…   1                                       [OK]
tiredofit/redis                  Redis Server w/ Zabbix monitoring and S6 Ove…   1                                       [OK]
cflondonservices/redis           Docker image for running redis                  0                                       
xetamus/redis-resource           forked redis-resource                           0                                       [OK]

```

* 拉取镜像
```
docker pull redis
```
```
[root@izj6c5c5zhif1dhww06p26z ~]# docker pull redis
Using default tag: latest
latest: Pulling from library/redis
1ab2bdfe9778: Pull complete 
966bc436cc8b: Pull complete 
c1b01f4f76d9: Pull complete 
8a9a85c968a2: Pull complete 
8e4f9890211f: Pull complete 
93e8c2071125: Pull complete 
Digest: sha256:9755880356c4ced4ff7745bafe620f0b63dd17747caedba72504ef7bac882089
Status: Downloaded newer image for redis:latest
[root@izj6c5c5zhif1dhww06p26z ~]# 
```

* 启动redis
```
docker run -p 10002:6379 -d redis:latest redis-server
```
```
[root@izj6c5c5zhif1dhww06p26z ~]# docker run -p 10002:6379 -d redis:latest redis-server
1021f20973919e0e37477ac6515e90772919a5445fb7272f4e51d0f9b880e5b6
[root@izj6c5c5zhif1hww06p26z ~]# ^C
[root@izj6c5c5zhif1dhww06p26z ~]# 

```

* 测试redis本机连接
```
[root@izj6c5c5zhif1dhww06p26z ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                                NAMES
1021f2097391        redis:latest        "docker-entrypoint.s…"   8 minutes ago       Up 8 minutes        0.0.0.0:10002->6379/tcp              ecstatic_hopper

[root@izj6c5c5zhif1dhww06p26z ~]# docker exec -it ecstatic_hopper redis-cli
127.0.0.1:6379> 
```
* 测试远程连接
![image.png](https://upload-images.jianshu.io/upload_images/10118469-821997bf86906009.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

