title: 支付demo篇（06）-支付对接 -微信支付二维码支付
date: '2019-09-06 13:39:15'
updated: '2019-09-06 13:39:15'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567748355174.html
---
##### 添加接口IPayService
```
 /**
     * 微信二维码支付
     * @param payOrderVo
     * @return
     */
    Map wxQrPay(PayOrderVo payOrderVo);
```
##### 添加接口实现PayService
```
@Override
    public Map unifiedOrder(PayOrderVo payOrderVo) {
        //支付宝支付
        if(payOrderVo.getPayType().equals(PayConstant.PayType.ALI_PAY)){
            //扫码支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.QR)) {
                return this.aliQrPay(payOrderVo);
            }
            //app支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.APP)) {
                return this.aliAppPay(payOrderVo);
            }
        }
 	//微信支付
        if(payOrderVo.getPayType().equals(PayConstant.PayType.WX_PAY)){
            //扫码支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.QR)) {
                return this.wxQrPay(payOrderVo);
            }
        }
        return null;
    }
```
```
 @Override
    public Map wxQrPay(PayOrderVo payOrderVo) {
        //金额转换 微信如果是0.01 需要转换为 1
        int prices = (int)(CoreUtil.getDOUBtoDF(payOrderVo.getAmount(),0)*100);
        Map<String,String> map = new HashMap<String,String>(){{
            put("appid",BaseValue.WX_APP_ID);
            put("mch_id",BaseValue.WX_MCH_ID);
            //交易类型trade_type 以下参数详见微信开发文档
            //https://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=4_2
            put("trade_type",PayConstant.TradeType.NATIVE);
            put("nonce_str",CoreUtil.MD5(BaseValue.WX_MCH_ID.trim()));
            //如果多商户架构 建议使用商户ID
            put("device_info",BaseValue.WX_MCH_ID.trim());
            put("body",payOrderVo.getSubject());
            put("detail",payOrderVo.getBody());
            //支付订单号 全局唯一 用于通信 demo版使用UUID MD5
            put("out_trade_no",CoreUtil.MD5(UUID.randomUUID().toString()));
            //总金额
            put("total_fee",""+prices);
            put("spbill_create_ip",payOrderVo.getClientIp());
            put("product_id",payOrderVo.getOrderId());
            put("notify_url", BaseValue.SYSTEM_NOTIFY_URL);
            put("sign_type",BaseValue.WX_SIGN_TYPE);
        }};
        try {
            map.put("sign", WxPayUtil.generateSignature(map, BaseValue.WX_MCH_KEY, BaseValue.WX_SIGN_TYPE));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        String xmlString = XMLBeanUtil.map2XmlString(map);
        //发送http请求
        String post = null;
        try {
            post = OkHttpClientUtil.doPost(BaseValue.WX_ORDER_URL, xmlString);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        //返回参数转化
        try {
            return XMLBeanUtil.doXMLParse(post);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return null;
    }
```
##### 测试调用
![image.png](https://img.hacpai.com/file/2019/09/image-a122a88f.png)
```
http://127.0.0.1:8080/pay?orderId=123456789&userId=123456789&mobile=123456789&openId=123456789&payType=WX_PAY&tradeType=QR&trxType=XF&subject=测试微信二维码支付subject&body=测试微信二维码支付body&clientIp=127.0.0.1&amount=0.01&remark=测试微信二维码支付
```
![image.png](https://img.hacpai.com/file/2019/09/image-2909018d.png)


##### 拉起微信二维码支付
* 将code_url字段的值使用在线的二维码生成器生成二维码进行微信支付
* 效果图
![image.png](https://img.hacpai.com/file/2019/09/image-a51f2e0c.png)

