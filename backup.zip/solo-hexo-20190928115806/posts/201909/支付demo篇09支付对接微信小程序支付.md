title: 支付demo篇（09）-支付对接 -微信小程序支付
date: '2019-09-06 15:35:35'
updated: '2019-09-06 15:35:35'
tags: [支付, JAVA]
permalink: /articles/2019/09/06/1567755335332.html
---
##### 添加接口IPayService
``` 
    /**
     * 微信小程序支付
     * @param payOrderVo
     * @return
     */
    Map wxAppletPay(PayOrderVo payOrderVo);
```

##### 添加接口PayService
```
 @Override
    public Map unifiedOrder(PayOrderVo payOrderVo) {
        //支付宝支付
        if(payOrderVo.getPayType().equals(PayConstant.PayType.ALI_PAY)){
            //扫码支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.QR)) {
                return this.aliQrPay(payOrderVo);
            }
            //app支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.APP)) {
                return this.aliAppPay(payOrderVo);
            }
        }
        //微信支付
        if(payOrderVo.getPayType().equals(PayConstant.PayType.WX_PAY)){
            //扫码支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.QR)) {
                return this.wxQrPay(payOrderVo);
            }
            //app支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.APP)) {
                return this.wxAppPay(payOrderVo);
            }
        }
        //微信小程序支付
        if(payOrderVo.getPayType().equals(PayConstant.PayType.WX_APPLET_PAY)){
            return this.wxAppletPay(payOrderVo);
        }
        return null;
    }
```

```
    @Override
    public Map wxAppletPay(PayOrderVo payOrderVo) {
        String totalFee = String.valueOf(new BigDecimal((payOrderVo.getAmount())).multiply(new BigDecimal(100)).intValue());
        Map<String, String> map = new HashMap<String, String>() {{
            put("appid",BaseValue.WX_APPLET_APP_ID);
            put("mch_id",BaseValue.WX_APPLET_MCH_ID);
            put("nonce_str", CoreUtil.MD5(payOrderVo.getOrderId()));
            //如果多商户架构 建议使用商户ID
            put("device_info", BaseValue.WX_APPLET_APP_ID);
            put("body", payOrderVo.getSubject());
            put("detail", payOrderVo.getBody());
            put("out_trade_no",CoreUtil.MD5(UUID.randomUUID().toString()));
            //交易金额
            put("total_fee",totalFee);
            put("spbill_create_ip", payOrderVo.getClientIp());
            //交易类型trade_type 以下参数详见微信开发文档
            //https://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=4_2
            put("trade_type", PayConstant.TradeType.JSAPI);
            //该openid为小程序下微信用户的openid 注意公众号和小程序不同
            put("openid", payOrderVo.getOpenId());
            put("notify_url", BaseValue.SYSTEM_NOTIFY_URL);
        }};
        String prestr = XMLBeanUtil.createLinkString(map);
        //微信支付签名
        String mysign = WxPayUtil.sign(prestr, BaseValue.WX_APPLET_MCH_KEY, "utf-8").toUpperCase();
        map.put("sign", mysign);
        logger.info("【微信小程序支付请求参数 map={}】",map);
        String xmlString = XMLBeanUtil.map2XmlString(map);
        String post = null;
        try {
            post = OkHttpClientUtil.doPost(BaseValue.WX_ORDER_URL, xmlString);
        } catch (Exception e) {
            logger.info("【微信小程序支付请求失败 {}】",e.getMessage());
        }
        try {
            return XMLBeanUtil.doXMLParse(post);
        } catch (Exception e) {
            logger.info("【微信小程序支付请求失败 {}】",e.getMessage());
        }
        return null;
    }
```
##### 测试接口（注意openid）
![image.png](https://img.hacpai.com/file/2019/09/image-5cae7db3.png)
![image.png](https://img.hacpai.com/file/2019/09/image-8c5ec42b.png)

##### 微信同样没有提供官方的测试工具需要小程序代码进行联调
* 经过测试本方法已经成功
